from project.sports_car import SportsCar

lamborgini = SportsCar()
print(lamborgini.move())
print(lamborgini.driver())
print(lamborgini.race())
