from project.car import Car


class SportCar(Car):
    DEFAULT_FUEL_CONSUMPTION = 10
